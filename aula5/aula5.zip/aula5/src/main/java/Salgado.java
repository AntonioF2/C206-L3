public class Salgado {

    String nome;

}
