public class Cantina {

    String nome;
    Salgado[] salgados = new Salgado[5];

    public void addSalgado(){

    }

    public void mostraInfo(){

    }

}
